package com.cg.billing.client;

import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import com.cg.billing.services.BillingServices;
import com.cg.billing.services.BillingServicesImpl;

public class TestMain {
	static BillingServicesImpl services = new BillingServicesImpl();

	public static void main(String[] args)
	{
		EntityManagerFactory entityManagerFactory = Persistence.createEntityManagerFactory("JPA-PU");
        services.createPlanDetails();
        
	}

}
